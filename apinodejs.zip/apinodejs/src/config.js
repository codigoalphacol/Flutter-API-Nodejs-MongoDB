module.exports = {
    secret: 'mysecrettoken'
}